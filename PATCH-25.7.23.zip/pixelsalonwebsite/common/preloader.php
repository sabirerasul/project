<div class="preloader">
    <div class="status">
        <div class="status-mes"></div>
    </div>
</div>