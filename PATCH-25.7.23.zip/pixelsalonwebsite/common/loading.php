<link rel="stylesheet" href="./assets/css/notice.min.css" />
<script src="./assets/js/notice.min.js"></script>
<script>
    const instanceLoading = new Notice();
</script>