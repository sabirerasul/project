<?php
require_once("./lib/db.php");
require_once('./lib/config-details.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <!-- PAGE TITLE -->
    <title> Book Appointment &#8211; <?= SALONNAME ?></title>
    <?php include('./common/head.php') ?>

    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

    <link rel="stylesheet" href="./assets/css/book-appointment.css">

    <link rel="stylesheet" href="./assets/css/mdtimepicker.css">

    <link rel="stylesheet" href="./assets/css/datepicker.min.css">
    <link rel="stylesheet" href="./assets/css/bootstrap-datetimepicker.css">

    <!-- <link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.13.2/themes/ui-lightness/jquery-ui.css" type="text/css" rel="stylesheet" /> -->


</head>

<body>
    <!-- START PRELOADER -->
    <?php include('./common/preloader.php') ?>
    <!-- / END PRELOADER -->

    <!-- START HOMEPAGE DESIGN AREA -->
    <?php include('./common/header.php') ?>
    <!-- / END HOMEPAGE DESIGN AREA -->

    <?php include('./common/breadcrumb.php') ?>

    <section id="features" class="features-area">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="section-title">
                        <h2>Book Appointment</h2>
                        <span class="title-divider">
                            <i class="fa icon-px-logo" aria-hidden="true"></i>
                        </span>
                    </div>
                </div>
            </div>
            <?php include('./form/appointment.php') ?>
        </div>
    </section>

    <?php include('./common/footer.php') ?>

    <!-- START SCROOL UP DESIGN AREA -->
    <?php include('./common/bottom-top.php') ?>
    <!-- / END SCROOL UP DESIGN AREA -->

    <?php include('./common/script.php') ?>

    <script type="text/javascript" src="./assets/js/validation.js"></script>
    <script type="text/javascript" src="./assets/js/toastify-js.js"></script>
    <script type="text/javascript" src="./assets/js/sweetalert2@11.js"></script>
    <script type="text/javascript" src="./assets/js/main.js"></script>
    <script type="text/javascript" src="./assets/js/pages/appointment.js"></script>
    <?php include('./common/loading.php'); ?>

    <script type="text/javascript" src="./assets/js/datepicker.min.js"></script>
    <script src="./assets/js/bootstrap-datetimepicker.min.js"></script>


    <script src="./assets/js/mdtimepicker.js"></script>

</body>

</html>