function dataTableLoad1() {
    var table = $('#dataTable1').DataTable();
}

function dataTableLoad2() {
    var table = $('#dataTable2').DataTable();
}

$(document).ready(function () {
    dataTableLoad1();
    dataTableLoad2();
});

