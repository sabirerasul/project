function myalert() {}

$(function () {
  window.localStorage.setItem("refresh", "1");
});
